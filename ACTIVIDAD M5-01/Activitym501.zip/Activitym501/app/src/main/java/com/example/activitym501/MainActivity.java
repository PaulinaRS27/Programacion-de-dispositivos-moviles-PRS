package com.example.activitym501;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    // Variables de la interfaz
    private TextView tvResultado;
    private Button btnSiguiente, btnAnterior;

    // Variables de control
    private int posicionActual = 0;

    // Se utilizo un HashMap para guardar resultados ya calculados
    // IMPORTANTE:La llave es la posicion (Integer) y el valor es el resultado (Long)
    private HashMap<Integer, Long> memo = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    // Llamamos a los módulos de configuración
        vincularComponentes();
        configurarEventos();
    }
        // Vinculación de componentes XML
        private void vincularComponentes() {
            tvResultado = findViewById(R.id.tvResultado);
            btnSiguiente = findViewById(R.id.btnSiguiente);
            btnAnterior = findViewById(R.id.btnAnterior);
        }
        //CONFIGURACIÓN DE BOTONES
            private void configurarEventos() {
        // Configuración del botón Siguiente
        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                posicionActual++; // Aumentamos la posición
                mostrarResultado();
            }
        });
        // Configuración del botón Anterior
        btnAnterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (posicionActual > 1) { // Evitamos que baje de 1
                    posicionActual--;
                    mostrarResultado();
                }
            }
        });
    }
    //ACTUALIZACIÓN DE VISTA
    private void mostrarResultado() {
        long resultado = calcularFibonacci(posicionActual);
        tvResultado.setText(String.valueOf(resultado));
    }
    //LOGICA MATEMATICA
    //Funcion con ciclo FOR y Memoización
    private long calcularFibonacci(int n) {
        //Si el número ya está en la memoización, NO entra al ciclo for
        if (memo.containsKey(n)) {
            return memo.get(n);
        }
        //CASOS BASE
        if (n <= 0) return 0;
        if (n == 1 || n == 2) return 1;

        //Calculos usando el ciclo FOR
        long ValorAnterior = 1; // Representa n-2
        long ValorActual = 1; // Representa n-1
        long resultado = 1;

        for (int i = 3; i <= n; i++) {
            resultado = ValorAnterior + ValorActual;
            ValorAnterior = ValorActual;
            ValorActual = resultado;
        }

        // Resultado guardado antes de retornar (memorizacion)
        memo.put(n, resultado);

        return resultado;
    }
}