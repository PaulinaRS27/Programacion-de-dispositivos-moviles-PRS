package com.example.miactivitym401;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Etiqueta para identificar mensaje en el Logcat
    private static final String TAG = "CicloVidaActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Este metodo se ejecuta cuando la actividad se crea por primera vez
        Log.d(TAG, "¡Hola! El sistema está cargando la interfaz.");
    }

    @Override
    protected void onStart() {
        super.onStart();
        // La actividad está a punto de hacerse visible para el usuario
        Log.d(TAG, "Interfaz lista");
    }

    @Override
    protected void onResume() {
        super.onResume();
        // La actividad es visible y el usuario ya puede interactuar con ella
        Log.d(TAG, "App lista para usarse");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // El sistema está a punto de poner otra actividad en primer plano
        Log.d(TAG, "Un momento porfavor");
    }

    @Override
    protected void onStop() {
        super.onStop();
        // La actividad ya no es visible para el usuario
        Log.d(TAG, "Pasando a segundo plano");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        // Se ejecuta cuando la actividad vuelve a mostrarse tras haber estado detenida
        Log.d(TAG, "¡De vuelta!");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Se ejecuta justo antes de que la actividad sea eliminada de la memoria
        Log.d(TAG, "Cerrando el sistema definitivamente");
    }
}