package com.example.actividadm3_01;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "M301LogcatTag"; // Etiqueta para filtrar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // CÓDIGO SIN INTERFAZ GRÁFICA

        Log.d(TAG, "--- INICIO DE PRUEBAS ---");

        // 1. Instanciar los módulos
        Calculadora calculadora = new Calculadora(); // Modulo de PROCESAMIENTO
        LogcatDisplay display = new LogcatDisplay(TAG); // Modulo de SALIDA

        // 2. Valores de prueba
        double num1 = 40.0f;
        double num2 = 8.0f;
        double cero = 0.0f;
        double resultado;

        // --- PRUEBAS NORMALES ---
        Log.d(TAG, "Prueba Suma: 40 + 8");
        resultado = calculadora.sumar(num1, num2);
        display.muestraResultado(resultado); // Uso de Display

        Log.d(TAG, "Prueba Resta: 40 - 8");
        resultado = calculadora.restar(num1, num2);
        display.muestraResultado(resultado); // Uso de Display

        Log.d(TAG, "Prueba Multiplicación: 40 * 8");
        resultado = calculadora.multiplicar(num1, num2);
        display.muestraResultado(resultado); // Uso de Display

        // --- PRUEBA DE DIVISIÓN POR CERO (NaN) ---
        Log.d(TAG, "Prueba División por Cero (Buscando NaN): 40 / 0");
        resultado = calculadora.dividir(num1, cero);

        // 3. Validación de NaN usando Display
        if (Double.isNaN(resultado)) {
            // Crear el objeto de error para IDisplay
            CalculadoraError error = new CalculadoraError("División por Cero. Resultado: NaN.");
            display.muestraError(error); // Uso de IDisplay para mostrar el error
        } else {
            display.muestraResultado(resultado);
        }

        Log.d(TAG, "--- FIN DE PRUEBAS ---");
    }
}