package com.example.actividadm3_01;

import android.util.Log;

public class LogcatDisplay implements Display {

    private final String TAG;

    // El constructor recibe la etiqueta TAG que se usará para Logcat
    public LogcatDisplay(String tag) {
        this.TAG = tag;
    }

    @Override
    public String muestraResultado(double res) {
        // En este contexto, mostramos el resultado en Logcat y retornamos el string.
        String resultado = String.valueOf(res);
        Log.d(TAG, "Resultado: " + resultado);
        return resultado;
    }

    @Override
    public String muestraError(CalculadoraError error) {
        // En este contexto, mostramos el error en Logcat (usando Log.e) y retornamos el string.
        String mensaje = "¡ERROR! " + error.mensaje;
        Log.e(TAG, mensaje);
        return mensaje;
    }
}
