package com.example.actividadm3_01;

// Clase mínima para representar un tipo de error que puede manejar IDisplay
public class CalculadoraError {
    public String mensaje;

    public CalculadoraError(String mensaje) {
        this.mensaje = mensaje;
    }
}