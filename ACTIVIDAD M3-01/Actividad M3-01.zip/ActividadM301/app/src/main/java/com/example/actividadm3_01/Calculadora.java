package com.example.actividadm3_01;

import static java.lang.Double.NaN; // Importa la constante para NaN

public class Calculadora implements Operaciones { // Implementa la interfaz

    @Override
    public double sumar(double num1, double num2) {
        return num1 + num2;
    }

    @Override
    public double restar(double num1, double num2) {
        return num1 - num2;
    }

    @Override
    public double multiplicar(double num1, double num2) {
        return num1 * num2;
    }

    @Override
    public double dividir(double num1, double num2) {
        // Validación de NaN: si el divisor es 0, retorna NaN
        if (num2 == 0) {
            return NaN;
        }
        return num1 / num2;
    }
}
