package com.example.actividadm3_01;

public interface Display
{
    // Define cómo mostrar un resultado float
    String muestraResultado(double res);

    // Define cómo mostrar un error tipificado
    String muestraError(CalculadoraError error);
}