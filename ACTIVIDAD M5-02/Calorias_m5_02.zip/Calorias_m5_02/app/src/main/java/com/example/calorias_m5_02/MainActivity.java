package com.example.calorias_m5_02;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Etiqueta para filtrar en el Logcat
    private static final String TAG = "SOLUCION";
    private static final String FILE_NAME = "datos.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ejecución
        procesarExpedicion();
    }
    private void procesarExpedicion() {
        try {
            List<Integer> inventarioElfos = obtenerTotalesPorElfo(FILE_NAME);

            if (inventarioElfos.isEmpty()) {
                Log.w(TAG, "No se encontraron datos para procesar.");
                return;
            }

            // Usamos Collections para obtener el máximo de forma orgánica
            int maxCalorias = Collections.max(inventarioElfos);

            mostrarResultado(maxCalorias);

        } catch (IOException e) {
            Log.e(TAG, "Error crítico de E/S: " + e.getMessage());
        }
    }
    private List<Integer> obtenerTotalesPorElfo(String fileName) throws IOException {
        List<Integer> totales = new ArrayList<>();
        int acumuladoActual = 0;
// Estructura try el cual intenta abrir el archivo assets
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(getAssets().open(fileName)))) {
//Estructura whilw el cual repite hasta el fin del archivo
            String linea;
            while ((linea = reader.readLine()) != null) {
                String contenido = linea.trim();
//Estructura if (Si la línea está vacía)
                if (contenido.isEmpty()) {
                    totales.add(acumuladoActual);
                    acumuladoActual = 0;
                    // Estructura else (si la linea tiene un numero)
                } else {
                    acumuladoActual += Integer.parseInt(contenido);
                }
            }
            // Agregar el último elfo si el archivo no termina en blanco
            if (acumuladoActual > 0) totales.add(acumuladoActual);
        }
        return totales;
    }

    private void mostrarResultado(int resultado) {
        Log.i(TAG, "==========================================");
        Log.i(TAG, "   RESULTADO DE LA EXPEDICIÓN    ");
        Log.i(TAG, "==========================================");
        Log.i(TAG, "ELFO CON MAYOR CANTIDAD: " + resultado + " CALORIAS");
        Log.i(TAG, "==========================================");
    }
}