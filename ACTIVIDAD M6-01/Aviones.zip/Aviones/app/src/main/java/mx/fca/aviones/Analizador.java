package mx.fca.aviones;

import java.util.ArrayList;
import java.util.HashMap;

public class Analizador {

    static HashMap<Integer, Plano> memoria = new HashMap<>();

    public static Plano inicializa(Plano plano) {
        memoria.put(0, plano);
        return plano;
    }

    public static Plano next(int noPaso, Plano planoAnterior) {
        if (memoria.containsKey(noPaso)) {
            return memoria.get(noPaso);
        } else {
            ArrayList<Avion> nuevosAviones = new ArrayList<>();
            // Colisiones que ya existían antes (Acumulación)
            ArrayList<Colision> colisionesAcumuladas = new ArrayList<>(planoAnterior.colisiones);

            // --- CALCULAR MOVIMIENTO ---
            for (Avion avion : planoAnterior.aviones) {
                int nuevoX = avion.x;
                int nuevoY = avion.y;

                switch (avion.direccion) {
                    case NORTH:
                        nuevoY--;
                        break;
                    case SOUTH:
                        nuevoY++;
                        break;
                    case EAST:
                        nuevoX++;
                        break;
                    case WEST:
                        nuevoX--;
                        break;
                }

                // Mundo Infinito
                if (nuevoX < 0) nuevoX = 4;
                if (nuevoX > 4) nuevoX = 0;
                if (nuevoY < 0) nuevoY = 4;
                if (nuevoY > 4) nuevoY = 0;

                nuevosAviones.add(new Avion(avion.direccion, nuevoX, nuevoY));
            }

            // --- 2. CALCULAR COLISIONES ---
            boolean huboChoqueNuevo = false;
            for (int i = 0; i < nuevosAviones.size(); i++) {
                for (int j = i + 1; j < nuevosAviones.size(); j++) {
                    Avion a1 = nuevosAviones.get(i);
                    Avion a2 = nuevosAviones.get(j);

                    if (a1.x == a2.x && a1.y == a2.y) {
                        colisionesAcumuladas.add(new Colision(a1.x, a1.y));
                        huboChoqueNuevo = true;
                    }
                }
            }

            // LOGICA DE DESAPARICIÓN
            ArrayList<Avion> avionesParaGuardar = nuevosAviones;
            if (huboChoqueNuevo) {
                avionesParaGuardar = new ArrayList<>(); // Lista vacía: los aviones "explotan"
            }

            // Guardamos este estado único en el historial
            Plano planoNuevo = new Plano(noPaso, avionesParaGuardar, colisionesAcumuladas);
            memoria.put(noPaso, planoNuevo);

            return planoNuevo;
        }
    }
    public static Plano prev(int noPaso) {

        return memoria.get(noPaso);
    }
}