package mx.fca.aviones;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AvionAdapter extends RecyclerView.Adapter<AvionHolder> {
    ArrayList<Object> items;

    public AvionAdapter(ArrayList<Object> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public AvionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.avion_view, parent, false);
        return new AvionHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AvionHolder holder, int position) {
        Object item = items.get(position);

        // Limpieza de celda (Para los 25 cuadros)
        if (item == null) {
            holder.imgAvion.setImageDrawable(null);
            holder.imgAvion.setRotation(0);
            holder.tvCoordenadas.setText("");
            return;
        }

        if (item instanceof Avion) {
            Avion a = (Avion) item;
            holder.imgAvion.setImageResource(a.getImage());
            holder.tvCoordenadas.setText("X:" + a.x + " Y:" + a.y);

            // Rotación
            switch (a.direccion) {
                case NORTH: holder.imgAvion.setRotation(270); break;
                case SOUTH: holder.imgAvion.setRotation(90); break;
                case EAST:  holder.imgAvion.setRotation(0); break;
                case WEST:  holder.imgAvion.setRotation(0); break;
            }
        } else if (item instanceof Colision) {
            Colision c = (Colision) item;
            holder.imgAvion.setImageResource(c.getImage());
            holder.imgAvion.setRotation(0);
            holder.tvCoordenadas.setText("CHOQUE");
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}