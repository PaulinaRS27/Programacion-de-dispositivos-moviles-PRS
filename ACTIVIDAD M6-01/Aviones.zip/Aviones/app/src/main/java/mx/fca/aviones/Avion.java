package mx.fca.aviones;

public class Avion {
    Direccion direccion;
    int x;
    int y;
    boolean colisionado = false; // Nueva variable para el punto de "Colisión"
//Constructor
    public Avion(Direccion direccion, int x, int y) {
        this.direccion = direccion;
        this.x = x;
        this.y = y;
    }

    // Lógica para el punto "Dirección del avión" y movimiento
    public void mover(int maxGrid) {
        switch (direccion) {
            case NORTH: y--; break;
            case SOUTH: y++; break;
            case EAST:  x++; break;
            case WEST:  x--; break;
        }

        // Lógica de "Mundo Infinito" (Si sale del grid, entra por el otro lado)
        if (x >= maxGrid) x = 0; else if (x < 0) x = maxGrid - 1;
        if (y >= maxGrid) y = 0; else if (y < 0) y = maxGrid - 1;
    }

    public int getImage() {
        // Si el avión chocó, devolvemos la imagen de colisión/explosión
        if (colisionado) {
            return R.mipmap.collision; // Imagen de la colision
        }

        switch (direccion){
            case NORTH: return R.mipmap.north;
            case SOUTH: return R.mipmap.south;
            case EAST:  return R.mipmap.east;
            case WEST:  return R.mipmap.west;
        }
        return R.mipmap.north;
    }

    // Metodo para crear una copia
    public Avion copiar() {
        Avion copia = new Avion(this.direccion, this.x, this.y);
        copia.colisionado = this.colisionado;
        return copia;
    }
}