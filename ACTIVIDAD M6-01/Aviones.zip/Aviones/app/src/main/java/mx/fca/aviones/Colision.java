package mx.fca.aviones;

public class Colision {
    int x;
    int y;

    public Colision(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getImage() {
        return R.mipmap.collision;
    }
}