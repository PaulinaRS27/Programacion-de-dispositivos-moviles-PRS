package mx.fca.aviones;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button btnSiguiente, btnAnterior;
    private TextView tvPasos, tvColisiones;
    private Plano plano;
    private RecyclerView listaAviones;
    private AvionAdapter adapter;
    private int contadorPasos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaAviones = findViewById(R.id.listaAviones);
        btnSiguiente = findViewById(R.id.btnSiguiente);
        btnAnterior = findViewById(R.id.btnAnterior);
        tvPasos = findViewById(R.id.tvPasos);
        tvColisiones = findViewById(R.id.tvColisiones);

        plano = Analizador.inicializa(new Plano(0, Aerolineas.AEROMEXICO(), new ArrayList<>()));
        adapter = new AvionAdapter(new ArrayList<>());
        listaAviones.setAdapter(adapter);
        listaAviones.setLayoutManager(new GridLayoutManager(this, 5));

        actualizarInterfaz();

        btnSiguiente.setOnClickListener(v -> {
            if (plano.colisiones.isEmpty()) {
                contadorPasos++;
                plano = Analizador.next(contadorPasos, plano);
                actualizarInterfaz();
            } else {
                Toast.makeText(this, "Simulación terminada", Toast.LENGTH_SHORT).show();
            }
        });

        btnAnterior.setOnClickListener(v -> {
            if (contadorPasos > 0) {
                contadorPasos--;
                plano = Analizador.prev(contadorPasos);
                actualizarInterfaz();
            }
        });
    }

    private void actualizarInterfaz() {
        tvPasos.setText("Pasos: " + contadorPasos);
        tvColisiones.setText("Colisiones: " + plano.colisiones.size());

        ArrayList<Object> mapaCompleto = new ArrayList<>();
        for (int i = 0; i < 25; i++) mapaCompleto.add(null);

        for (Avion a : plano.aviones) {
            int idx = (a.y * 5) + a.x;
            if (idx >= 0 && idx < 25) mapaCompleto.set(idx, a);
        }

        for (Colision c : plano.colisiones) {
            int idx = (c.y * 5) + c.x;
            if (idx >= 0 && idx < 25) mapaCompleto.set(idx, c);
        }

        adapter.items = mapaCompleto;
        adapter.notifyDataSetChanged();
    }
}