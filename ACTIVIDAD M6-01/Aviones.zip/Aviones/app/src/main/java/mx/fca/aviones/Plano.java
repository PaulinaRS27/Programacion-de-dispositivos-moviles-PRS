package mx.fca.aviones;

import android.util.Log;
import java.util.ArrayList;

public class Plano {

    public ArrayList<Avion> aviones;
    public ArrayList<Colision> colisiones;
    public int col;
    public int row;
    public int noPaso;

    // Constructor completo con Logs
    public Plano(int noPaso, ArrayList<Avion> aviones, ArrayList<Colision> colisiones) {
        this.noPaso = noPaso;
        this.aviones = aviones;
        this.colisiones = colisiones;

        int tmpX = 0;
        int tmpY = 0;

        for (Avion avion : aviones) {
            if (avion.x > tmpX) {
                tmpX = avion.x;
            }
            if (avion.y > tmpY) {
                tmpY = avion.y;
            }
        }

        this.col = tmpX;
        this.row = tmpY;

        // Registro en Logcat
        Log.i("Aviones max de columna", String.valueOf(col));
        Log.i("Aviones max de renglon", String.valueOf(row));
    }

    public Plano next() {
        Log.i("Paso actual:", String.valueOf(noPaso));
        // Pedimos al Analizador el siguiente paso basándonos en este plano
        return Analizador.next(this.noPaso + 1, this);
    }

    public Plano prev() {
        // Implementación del historial usando la memoria del Analizador
        if (this.noPaso > 0) {
            return Analizador.prev(this.noPaso - 1);
        }
        return this;
    }

    public int getNumeroColisiones() {
        return colisiones.size();
    }

    public int getNumeroAviones() {
        return aviones.size();
    }
}