package mx.fca.aviones;

public enum Direccion {

    NORTH, SOUTH, EAST, WEST;
}
