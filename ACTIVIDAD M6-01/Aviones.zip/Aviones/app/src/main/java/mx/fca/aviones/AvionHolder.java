package mx.fca.aviones;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AvionHolder extends RecyclerView.ViewHolder {

    // Declaramos ambos componentes
    public ImageView imgAvion;
    public TextView tvCoordenadas;

    public AvionHolder(@NonNull View itemView) {
        super(itemView);

        // Enlazamos con los IDs que pusimos en avion_view.xml
        imgAvion = itemView.findViewById(R.id.imgAvion);
        tvCoordenadas = itemView.findViewById(R.id.tvCoordenadas);
    }
}